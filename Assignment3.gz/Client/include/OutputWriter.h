#include "../include/connectionHandler.h"
#include "string"
#include <atomic>
#include <mutex>
#include <condition_variable>

#ifndef BOOST_ECHO_CLIENT_OUTPUTWRITER_H
#define BOOST_ECHO_CLIENT_OUTPUTWRITER_H


class OutputWriter {
public:
    void run();
    OutputWriter(ConnectionHandler &connectionHandler,bool &shouldTerminate, bool &canProceed, std::mutex &mutex, std::condition_variable &cv);

private:
    ConnectionHandler& connectionHandler;
    bool& shouldTerminate;
    bool &canProceed;
    std::mutex &mutex;
    std::condition_variable &cv;
    std::string answer;
};


#endif //BOOST_ECHO_CLIENT_OUTPUTWRITER_H
