#include "../include/connectionHandler.h"
#include "string"
#include <mutex>
#include <condition_variable>


#ifndef BOOST_ECHO_CLIENT_INPUTREADER_H
#define BOOST_ECHO_CLIENT_INPUTREADER_H


class InputReader {
public:
    InputReader(ConnectionHandler &connectionHandler, bool &shouldTerminate, bool &canProceed, std::mutex &mutex, std::condition_variable &cv);
    void run();
    void convertToBytes(const std::string& input, char bytes[], int &len);
    void shortToBytes(short num, char bytesArr[], int& len);
    short getOptcode(std::string command);
    void convertByUserAndPassword(const std::string& input, const std::string& command, char bytesArr[], int& len);
    void convertByCourseNumber(const std::string& input, const std::string& command, char bytesArr[], int& len);

private:
    ConnectionHandler &connectionHandler;
    bool &shouldTerminate;
    bool &canProceed;
    std::mutex &mutex;
    std::condition_variable &cv;
    int len;
    short optcode;

};


#endif //BOOST_ECHO_CLIENT_INPUTREADER_H
