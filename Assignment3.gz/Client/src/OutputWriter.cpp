#include "../include/OutputWriter.h"
#include "string"
#include "iostream"

OutputWriter::OutputWriter(ConnectionHandler &_connectionHandler, bool &_shouldTerminate, bool &_canProceed, std::mutex &_mutex, std::condition_variable &_cv): connectionHandler(_connectionHandler), shouldTerminate(_shouldTerminate), canProceed(_canProceed),mutex(_mutex),cv(_cv), answer("") {}
void OutputWriter::run() {
    while (!shouldTerminate) {
        answer="";
        if (!connectionHandler.getLine(answer)) {
            std::cout << "Disconnected. Exiting...\n" << std::endl;
            break;
        }
        std::cout << answer << std::endl;
        if(answer=="ACK 4"|| answer=="ERROR 4"){
            std::unique_lock<std::mutex>lock(mutex);
            if(answer=="ACK 4"){
                shouldTerminate=true;
                canProceed= true;
                cv.notify_all();
            }
            else{
                if(answer=="ERROR 4"){
                    canProceed= true;
                    cv.notify_all();
                }
            }
        }

    }
}

