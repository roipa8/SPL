package bgu.spl.net.impl.Commands;

import bgu.spl.net.impl.BgrsProtocol;


public class CourseRegCommand extends Command {

    public CourseRegCommand(short optcode, int CourseNumber) {
        super(optcode, CourseNumber);
    }

    @Override
    public Command execute(BgrsProtocol protocol) {
        if(database.canRegisterToCourse(protocol.getUser(), CourseNumber)){
            return new AckCommand(optcode);
        }
        else{
            return new ErrorCommand(optcode);
        }
    }
}
