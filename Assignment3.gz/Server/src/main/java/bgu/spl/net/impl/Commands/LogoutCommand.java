package bgu.spl.net.impl.Commands;

import bgu.spl.net.impl.BgrsProtocol;

public class LogoutCommand extends Command {

    public LogoutCommand(short optcode) {
        super(optcode);
    }

    @Override
    public Command execute(BgrsProtocol protocol) {
        if(protocol.getUser()!=null){
            database.setLogout(protocol.getUser());
            protocol.setShouldTerminate(true);
            protocol.setUser(null);
            return new AckCommand(optcode);
        }
        else{
            return new ErrorCommand(optcode);
        }
    }
}
