package bgu.spl.net.impl;

import bgu.spl.net.api.MessagingProtocol;
import bgu.spl.net.impl.Commands.Command;
import bgu.spl.net.srv.User;

public class BgrsProtocol implements MessagingProtocol<Command> {

    private boolean shouldTerminate=false;
    private User user;
    @Override
    public Command process(Command msg) {
        return msg.execute(this);
    }

    public void setShouldTerminate(boolean shouldTerminate) {
        this.shouldTerminate = shouldTerminate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }


    @Override
    public boolean shouldTerminate() {
        return shouldTerminate;
    }

}
