package bgu.spl.net.impl.Commands;

import bgu.spl.net.impl.BgrsProtocol;


public class AdminRegCommand extends Command {


    public AdminRegCommand(String userName, String password, short optcode) {
        super(userName, password,optcode);
    }

    @Override
    public Command execute(BgrsProtocol protocol) {
        if(database.canAdminRegister(protocol.getUser(), userName, password)){
            return new AckCommand(optcode);
        }
        else{
            return new ErrorCommand(optcode);
        }
    }
}
