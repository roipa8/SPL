package bgu.spl.net.srv;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.stream.Stream;

/**
 * Passive object representing the Database where all courses and users are stored.
 * <p>
 * This class must be implemented safely as a thread-safe singleton.
 * You must not alter any of the given public methods of this class.
 * <p>
 * You can add private fields and methods to this class as you see fit.
 */
public class Database {
	private HashMap<String, User> userHashMap;
	private HashMap<Integer, Course> courseHashMap;
	private HashMap<Integer, Integer> coursesPlaceAtTheCourseFile;
	int countCourseFile;
	Object lockStudent;
	Object lockAdmin;



	//to prevent user from creating new Database
	private Database() {
		userHashMap=new HashMap<>();
		courseHashMap=new HashMap<>();
		coursesPlaceAtTheCourseFile=new HashMap<>();
		countCourseFile=1;
		lockStudent=new Object();
		lockAdmin=new Object();
		initialize("./Courses.txt");

	}
	private static class SingletonHolder{
		private static Database instance=new Database();
	}

	/**
	 * Retrieves the single instance of this class.
	 */
	public static Database getInstance() {
		return SingletonHolder.instance;
	}
	
	/**
	 * loades the courses from the file path specified 
	 * into the Database, returns true if successful.
	 */
	boolean initialize(String coursesFilePath) {
			try{
				File file=new File(coursesFilePath);
				Scanner scanner=new Scanner(file);
				while (scanner.hasNextLine()){
					String[] dataOfCourse=scanner.nextLine().split("\\|");
					int []kdamCourses=new int[0];
					if(dataOfCourse[2].length()>=3) {// checks that the KdamCoursesList isn't empty (length 2 means [])
						kdamCourses = Stream.of(dataOfCourse[2].substring(1, dataOfCourse[2].length() - 1).split(",")).mapToInt(Integer::parseInt).toArray();
					}
					courseHashMap.put(Integer.parseInt(dataOfCourse[0]),new Course(Integer.parseInt(dataOfCourse[0]),dataOfCourse[1],kdamCourses,Integer.parseInt(dataOfCourse[3])));
					coursesPlaceAtTheCourseFile.put(Integer.parseInt(dataOfCourse[0]),countCourseFile);
					countCourseFile=countCourseFile+1;
				}
				return true;
			}
			catch (FileNotFoundException ex){
				ex.printStackTrace();
			}
			return false;
	}



	public synchronized void setLogout(User user){
		user.setLogin(false);
		userHashMap.replace(user.getUserName(), user);
	}

	public boolean hasCourseStatConditions(User user, int CourseNumber){
		synchronized (lockAdmin){
			return user!=null && courseHashMap.containsKey(CourseNumber) && user.isAdmin();
		}
	}

	public boolean canRegisterToCourse(User user, int CourseNumber){
		synchronized (lockStudent){
			if(user!=null && courseHashMap.containsKey(CourseNumber)){
				Course course=courseHashMap.get(CourseNumber);
				if(!user.isRegister(CourseNumber) && course.getAvailableSpots()>0 && hasKdamCourses(user, course) && !user.isAdmin()){
					user.setCourse(CourseNumber);
					course.addStudentToCourse(user.getUserName());
					userHashMap.replace(user.getUserName(), user);
					return true;
				}
			}
			return false;
		}
	}
	public boolean hasKdamCheckConditions(User user, int CourseNomber){
		synchronized (lockStudent){
			return user!=null && courseHashMap.containsKey(CourseNomber) && !user.isAdmin();
		}
	}

	public boolean hasUnRegisterConditions(User user, int CourseNumber){
		synchronized (lockStudent){
			if(user!=null && user.isRegister(CourseNumber) && !user.isAdmin()){
				user.deleteCourse(CourseNumber);
				courseHashMap.get(CourseNumber).removeStudentFromCourse(user.getUserName());
				courseHashMap.get(CourseNumber).setOneMoreSpot();
				userHashMap.replace(user.getUserName(), user);
				return true;
			}
			return false;
		}
	}

	public boolean hasKdamCourses(User user, Course course){
		int[] kdamArr = course.getKdamCoursesList();
		for(int i = 0; i<kdamArr.length;i++){
			if(!user.isRegister(kdamArr[i])){
				return false;
			}
		}
		return true;
	}

	public synchronized boolean hasLoginConditions(String userName, String password){
		if(userHashMap.containsKey(userName) && userHashMap.get(userName).getPassword().equals(password) && !userHashMap.get(userName).isLogin()){
			userHashMap.get(userName).setLogin(true);
			return true;
		}
		return false;
	}

	public boolean hasStudentStatConditions(User user, String userName){
		synchronized (lockAdmin){
			return user!=null && user.isLogin() && user.isAdmin() && userHashMap.containsKey(userName);
		}
	}
	public boolean hasIsRegisteredConditions(User user, int CourseNumber){
		synchronized (lockStudent){
			return user!=null && user.isLogin() && !user.isAdmin() && courseHashMap.containsKey(CourseNumber);
		}
	}

	public boolean hasMyCoursesConditions(User user){
		synchronized (lockStudent){
			return user!=null && user.isLogin() && !user.isAdmin();
		}
	}

	public boolean canStudentRegister(User _user, String userName, String password){
		synchronized (lockStudent){
			if(userHashMap.containsKey(userName)||_user!=null){
				return false;
			}
			User user=new User(userName,password);
			userHashMap.put(userName, user);
			return true;
		}
	}

	public boolean canAdminRegister(User _user,String userName, String password){
		synchronized (lockAdmin){
			if(userHashMap.containsKey(userName)||_user!=null){
				return false;
			}
			User user=new User(userName,password);
			user.setAdmin(true);
			userHashMap.put(userName, user);
			return true;
		}
	}


	public HashMap<String, User> getUserHashMap() {
		return userHashMap;
	}

	public HashMap<Integer, Course> getCourseHashMap() {
		return courseHashMap;
	}

	public HashMap<Integer, Integer> getCoursesPlaceAtTheCourseFile() {
		return coursesPlaceAtTheCourseFile;
	}
}
