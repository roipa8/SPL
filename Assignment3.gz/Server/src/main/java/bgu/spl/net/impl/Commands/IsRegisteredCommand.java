package bgu.spl.net.impl.Commands;

import bgu.spl.net.impl.BgrsProtocol;

public class IsRegisteredCommand extends Command {

    public IsRegisteredCommand(short optcode, int CourseNumber) {
        super(optcode, CourseNumber);
    }

    @Override
    public Command execute(BgrsProtocol protocol) {
        if(database.hasIsRegisteredConditions(protocol.getUser(), CourseNumber)){
            return new AckCommand(optcode, CourseNumber, protocol.getUser().getUserName());
        }
        else{
            return new ErrorCommand(optcode);
        }
    }
}
