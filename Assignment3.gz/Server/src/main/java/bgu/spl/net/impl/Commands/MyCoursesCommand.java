package bgu.spl.net.impl.Commands;

import bgu.spl.net.impl.BgrsProtocol;

public class MyCoursesCommand extends Command{

    public MyCoursesCommand(short optcode) {
        super(optcode);
    }

    @Override
    public Command execute(BgrsProtocol protocol) {
        if(database.hasMyCoursesConditions(protocol.getUser())){
            return new AckCommand(protocol.getUser().getUserName(), optcode);
        }
        else{
            return new ErrorCommand(optcode);
        }
    }
}
