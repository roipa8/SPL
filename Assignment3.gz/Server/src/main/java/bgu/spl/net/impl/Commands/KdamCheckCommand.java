package bgu.spl.net.impl.Commands;

import bgu.spl.net.impl.BgrsProtocol;

public class KdamCheckCommand extends Command {
    public KdamCheckCommand(short optcode, int CourseNumber) {
        super(optcode, CourseNumber);
    }

    @Override
    public Command execute(BgrsProtocol protocol) {
        if(database.hasKdamCheckConditions(protocol.getUser(), CourseNumber)){
            return new AckCommand(optcode, CourseNumber);
        }
        else{
            return new ErrorCommand(optcode);
        }
    }
}
