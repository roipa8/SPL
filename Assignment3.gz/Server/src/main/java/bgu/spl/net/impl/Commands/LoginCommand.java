package bgu.spl.net.impl.Commands;

import bgu.spl.net.impl.BgrsProtocol;

public class LoginCommand extends Command{

    public LoginCommand(String userName, String password, short optcode) {
        super(userName, password, optcode);
    }

    @Override
    public Command execute(BgrsProtocol protocol) {
        if(database.hasLoginConditions(userName, password)){
            protocol.setUser(database.getUserHashMap().get(userName));
            return new AckCommand(optcode);
        }
        else{
            return new ErrorCommand(optcode);
        }
    }
}
