package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;

public class TestMicroService extends MicroService {
    public TestMicroService(){
        super("");
    }
    protected void initialize() {

    }
}
