package bgu.spl.mics;


import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;


/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {
    private ConcurrentHashMap<String, LinkedBlockingQueue<Message>> HMQueue; //Hash-map that was made to connect between the micro-services by their names to their queue of messages
    private HashMap<Class<? extends Message>, LinkedList<String>> HMType; // Hash-map that was made to connect between the type of message to the matching micro-services
    private HashMap<Event, Future> HMFuture; // Hash-map that was made to connect between the event to it's future


    private static class SingletonHolder {
        private static MessageBusImpl instance = new MessageBusImpl();
    }

    private MessageBusImpl() {
        HMType = new HashMap<>();
        HMFuture = new HashMap<>();
        HMQueue = new ConcurrentHashMap<>();
    }

    public static MessageBusImpl getInstance() {
        return SingletonHolder.instance;
    }


    @Override
    public synchronized <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
        if (HMType.containsKey(type)) {
            LinkedList<String> list = HMType.get(type);
            list.add(m.getName());
        } else {
            LinkedList<String> list = new LinkedList<>();
            list.add(m.getName());
            HMType.put(type, list);
        }
    }

    @Override
    public synchronized void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
        if (HMType.containsKey(type)) {
            LinkedList<String> list = HMType.get(type);
            list.add(m.getName());
        } else {
            LinkedList<String> list = new LinkedList<>();
            list.add(m.getName());
            HMType.put(type, list);
        }
    }

    @Override
    public <T> void complete(Event<T> e, T result) {
        HMFuture.get(e).resolve(result);

    }

    @Override
    public synchronized void sendBroadcast(Broadcast b) {
        if (HMType.containsKey(b.getClass())) {
            if (HMType.get(b.getClass()).isEmpty()) {
                throw new NullPointerException("No micros-service has subscribed to " + b.getClass().getName());
            }
            LinkedList<String> list = HMType.get(b.getClass());
            for (String s : list) {
                if (!HMQueue.containsKey(s)) {
                    throw new NullPointerException("Micro-service " + s + " didn't register");
                }
                LinkedBlockingQueue<Message> q = HMQueue.get(s);
                q.add(b);
            }
            notifyAll();
        }

    }


    @Override
    public synchronized <T> Future<T> sendEvent(Event<T> e) {
        Future<T> future = new Future<>();
        if (!HMType.containsKey(e.getClass()) || HMType.get(e.getClass()).isEmpty()) { //if the micro-service didn't subscribe
            return null;
        }
        // adding according to round-robin
        LinkedList<String> list = HMType.get(e.getClass());
        String temp = list.get(0);
        list.removeFirst();
        if (!HMQueue.containsKey(temp)) { //if the micro-service didn't register
            return null;
        }
        LinkedBlockingQueue<Message> q = HMQueue.get(temp);
        q.add(e);
        list.addLast(temp);
        HMFuture.put(e, future);
        notifyAll();
        return future;
    }

    @Override
    public void register(MicroService m) {
        LinkedBlockingQueue<Message> q = new LinkedBlockingQueue<>();
        HMQueue.put(m.getName(), q);
    }

    @Override
    public synchronized void unregister(MicroService m) {
        HMQueue.remove(m.getName());
        for (Class<? extends Message> type : HMType.keySet()) {
            LinkedList<String> list = HMType.get(type);
            while (list.contains(m.getName())) {
                list.remove(m.getName());
            }
        }
    }

    @Override
    public synchronized Message awaitMessage(MicroService m) {
        Message msg = null;
        if (HMQueue.containsKey(m.getName())) {
            LinkedBlockingQueue<Message> q = HMQueue.get(m.getName());
            while (q.isEmpty()) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            msg = q.remove();
        }
        return msg;

    }
}
